# Brick Demo for the IoT Course at the University of Southern Denmark

## Requirements

- `python3` for the interpreter
- `python3-rdflib` for RDF support

## Demo Execution

```shell
cd src ; ./demo
```

